# PuntoRojo Manager

Aplicación Android nativa inicial para administrar clientes PPPoE de PuntoRojo.

## Estado de esta entrega (0.1.1)
- Panel principal con resumen.
- Listado de clientes de demostración.
- Alta local de clientes y cambio de estado visual.
- Pantalla de conexión MikroTik preparada como placeholder.
- Arranque de Gradle incluido para Linux/macOS (`./gradlew`) y Windows (`gradlew.bat`).
- Flujo GitHub Actions que compila y publica el APK de depuración.

## Corrección del error de compilación
La entrega anterior no incluía el archivo `gradlew`, por lo que cualquier entorno que ejecutara `./gradlew` fallaba con `No such file or directory` y código 127. Esta versión incluye un lanzador que descarga Gradle 8.9 si no está instalado y ejecuta la compilación desde la raíz del proyecto. Requiere conexión a Internet la primera vez, además de JDK 17, `curl` o `wget` y `unzip` en Linux/macOS.

## Seguridad y limitaciones importantes
- Esta versión NO se conecta al CCR1036 y NO ejecuta comandos en el router.
- Los clientes de esta primera versión viven solo en memoria y se pierden al cerrar la app.
- No introducir contraseñas reales ni datos de abonados en esta versión.
- La integración real se hará después de definir acceso seguro, permisos mínimos y confirmación explícita de cada acción.

## Compilar localmente
Linux/macOS:
```bash
chmod +x gradlew
./gradlew :app:assembleDebug
```

Windows:
```bat
gradlew.bat :app:assembleDebug
```

El APK se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Compilar desde GitHub
1. Sube el contenido de esta carpeta al repositorio `Puntorojomanager`, conservando las carpetas y el archivo `gradlew`.
2. Abre **Actions** y ejecuta **Build Android APK** (o espera a que termine el flujo tras subir a `main`).
3. Abre la ejecución terminada, entra en **Artifacts** y descarga `PuntoRojoManager-debug`.
4. Extrae el ZIP descargado e instala `app-debug.apk` en Android.
