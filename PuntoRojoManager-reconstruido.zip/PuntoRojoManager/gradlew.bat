@echo off
setlocal
set "APP_HOME=%~dp0"
set "GRADLE_VERSION=8.9"
if "%GRADLE_USER_HOME%"=="" set "GRADLE_USER_HOME=%USERPROFILE%\.gradle"
set "GRADLE_HOME=%GRADLE_USER_HOME%\puntorojo-wrapper\gradle-%GRADLE_VERSION%"
set "GRADLE_BIN=%GRADLE_HOME%\bin\gradle.bat"
if not exist "%GRADLE_BIN%" (
  echo Descargando Gradle %GRADLE_VERSION%...
  if not exist "%GRADLE_USER_HOME%\puntorojo-wrapper" mkdir "%GRADLE_USER_HOME%\puntorojo-wrapper"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; Invoke-WebRequest 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_USER_HOME%\puntorojo-wrapper\gradle.zip'; Expand-Archive -Force '%GRADLE_USER_HOME%\puntorojo-wrapper\gradle.zip' '%GRADLE_USER_HOME%\puntorojo-wrapper'; Remove-Item '%GRADLE_USER_HOME%\puntorojo-wrapper\gradle.zip'"
  if errorlevel 1 exit /b 1
)
call "%GRADLE_BIN%" -p "%APP_HOME%" %*
exit /b %ERRORLEVEL%
