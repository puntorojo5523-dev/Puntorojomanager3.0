package com.puntorojo.manager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("puntorojo_local", MODE_PRIVATE) }
    private val customers = ArrayList<JSONObject>()
    private lateinit var list: LinearLayout
    private lateinit var summary: TextView
    private val red = Color.rgb(220, 45, 45)
    private val bg = Color.rgb(17, 18, 22)
    private val panel = Color.rgb(31, 33, 39)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadCustomers()
        render()
    }

    private fun loadCustomers() {
        customers.clear()
        val raw = prefs.getString("customers", "[]") ?: "[]"
        try { val a = JSONArray(raw); for (i in 0 until a.length()) customers.add(a.getJSONObject(i)) } catch (_: Exception) { }
    }

    private fun saveCustomers() {
        val a = JSONArray(); customers.forEach { a.put(it) }
        prefs.edit().putString("customers", a.toString()).apply()
    }

    private fun render() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(20, 24, 20, 16) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val brand = label("PUNTOROJO", 14, red, true)
        content.addView(brand)
        content.addView(label("Manager", 30, Color.WHITE, true))
        content.addView(label("Administración de clientes · RD$", 14, Color.LTGRAY, false))
        summary = label("", 16, Color.WHITE, true)
        val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(16, 16, 16, 16); setBackgroundColor(panel) }
        card.addView(summary)
        card.addView(label("Control local de clientes PPPoE", 13, Color.LTGRAY, false))
        content.addView(card, params( ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, 0, 18, 0, 16))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val add = Button(this).apply { text = "+ Agregar cliente"; setOnClickListener { addCustomerDialog() } }
        actions.addView(add, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        content.addView(actions)
        content.addView(label("Clientes registrados", 20, Color.WHITE, true))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(list)
        content.addView(label("Aviso: esta versión guarda datos en el teléfono. Todavía no se conecta al MikroTik ni ejecuta suspensiones reales.", 13, Color.rgb(255,180,90), false))
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = label("PuntoRojo Manager  ·  versión 0.2.0", 12, Color.GRAY, false)
        footer.gravity = Gravity.CENTER
        root.addView(footer)
        setContentView(root)
        refreshList()
    }

    private fun refreshList() {
        list.removeAllViews()
        var total = 0
        customers.forEachIndexed { index, c ->
            total += c.optInt("price")
            val row = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 12); setBackgroundColor(panel) }
            val top = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(label(c.optString("name"), 16, Color.WHITE, true))
            details.addView(label("${c.optString("user")} · ${c.optString("plan")}", 13, Color.LTGRAY, false))
            details.addView(label("RD$ ${c.optInt("price")}", 14, red, true))
            top.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            val active = c.optBoolean("active", true)
            val toggle = Button(this).apply { text = if (active) "Activo" else "Inactivo"; setOnClickListener {
                c.put("active", !c.optBoolean("active", true)); saveCustomers(); refreshList()
            } }
            top.addView(toggle)
            row.addView(top)
            val del = TextView(this).apply { text = "Eliminar registro"; setTextColor(Color.LTGRAY); textSize = 12f; gravity = Gravity.END; setPadding(0, 8, 0, 0); setOnClickListener {
                AlertDialog.Builder(this@MainActivity).setMessage("¿Eliminar este cliente del registro local?").setNegativeButton("Cancelar", null).setPositiveButton("Eliminar") { _, _ -> customers.removeAt(index); saveCustomers(); refreshList() }.show()
            } }
            row.addView(del)
            list.addView(row, params(-1, -2, 0, 8, 0, 0))
        }
        summary.text = "Clientes: ${customers.size}     Activos: ${customers.count { it.optBoolean("active", true) }}\nFacturación mensual estimada: RD$ $total"
    }

    private fun addCustomerDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 0) }
        fun field(hint: String): EditText { return EditText(this).apply { this.hint = hint; setSingleLine(true); setTextColor(Color.BLACK) } }
        val name = field("Nombre completo")
        val user = field("Usuario PPPoE")
        val plan = field("Plan (ej. 30 MB)")
        val price = field("Precio mensual RD$")
        price.inputType = 2
        box.addView(name); box.addView(user); box.addView(plan); box.addView(price)
        AlertDialog.Builder(this).setTitle("Nuevo cliente").setView(box).setNegativeButton("Cancelar", null).setPositiveButton("Guardar", null).create().also { dialog ->
            dialog.setOnShowListener {
                dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                    val amount = price.text.toString().toIntOrNull()
                    if (name.text.isBlank() || user.text.isBlank() || plan.text.isBlank() || amount == null || amount <= 0) {
                        Toast.makeText(this, "Completa los datos y verifica el precio", Toast.LENGTH_SHORT).show()
                    } else {
                        customers.add(JSONObject().put("name", name.text.toString().trim()).put("user", user.text.toString().trim()).put("plan", plan.text.toString().trim()).put("price", amount).put("active", true))
                        saveCustomers(); refreshList(); dialog.dismiss()
                    }
                }
            }
            dialog.show()
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text; textSize = size.toFloat(); setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
        setPadding(0, 5, 0, 5)
    }

    private fun params(w: Int, h: Int, l: Int, t: Int, r: Int, b: Int) = LinearLayout.LayoutParams(w, h).apply { setMargins(l, t, r, b) }
}
